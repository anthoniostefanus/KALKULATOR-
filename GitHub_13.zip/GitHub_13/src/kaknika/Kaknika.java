/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kaknika;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Kaknika {

    /**
     * @param args the command line arguments
     * 
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        float abc=0;
        float def=0;
        
        System.out.print("masukkan angka 1=");
        abc = scan.nextFloat();
        System.out.print("masukkan angka 2=");
        def = scan.nextFloat();
        
        System.out.println("hasil penjumlahan = "+(abc + def));
        System.out.println("hasil pengurangan = "+ (abc - def));
        System.out.println("hasil perkalian = "+ (abc * def));
        System.out.println("hasil pembagian = "+(abc / def));
     
        
    }
    
}
